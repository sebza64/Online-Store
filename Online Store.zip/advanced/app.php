<?php
 
//LDAP Bind paramters, need to be a normal AD User account.
$ldap_password = 'AD_Password';
$ldap_username = 'AD_Username@domain.tld';
$ldap_connection = ldap_connect("domain.tld");
 
if (FALSE === $ldap_connection) {
    // Uh-oh, something is wrong...
    echo 'Unable to connect to the ldap server';
}
 
// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
 


$ldaprdn  = $_POST["username"];
    $ldappass = $_POST["password"];
    $ldapconn = ldap_connect("ldap server name") or die("Could not connect to LDAP server.");

if ($ldapconn) 
{
    $ldapbind = ldap_bind($ldapconn, $ldaprdn, $ldappass);
    if ($ldapbind) 
    {
        echo "LDAP bind successful...";
    }
    else 
    {
        echo "LDAP bind failed...";
    }
}
$Result = ldap_search($ldapconn, "OU=IT,DC="Domain",DC=corp", "(samaccountname=$ldaprdn)", array("dn"));
$data = ldap_get_entries($ldapconn, $Result);
print_r($data);
?>